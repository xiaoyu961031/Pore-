# Accessible_Surface_Area
A Fortran programme to calculate the fractional chemical surface area of a crystal structure.
